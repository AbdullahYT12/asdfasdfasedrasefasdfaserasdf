module.exports = {
    prefix: "!",
    youtubekey: "AIzaSyBH6wpTS9KBexV5zsfvslZF5T8Q5iZ8CPg"
}
